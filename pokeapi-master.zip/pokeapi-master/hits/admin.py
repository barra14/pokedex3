from .models import ResourceView
from django.contrib import admin

admin.site.register(ResourceView)
